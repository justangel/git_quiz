﻿. .\Shared\Shared_Logs.ps1

function ChechUserDBRights ($serverName)
{
	LogImportant ("Call ChechUserDBRights")

	$Env:PSModulePath=$Env:PSModulePath+";C:\Program Files (x86)\Microsoft SQL Server\110\Tools\PowerShell\Modules\"
	Import-Module “sqlps” -DisableNameChecking -ErrorAction Stop
	
	$serverConnection = new-object Microsoft.SqlServer.Management.Common.ServerConnection
	$serverConnection.ServerInstance=$serverName
 
	$currentLoginName= [Environment]::UserDomainName+"\"+[Environment]::UserName
	$server = new-object Microsoft.SqlServer.Management.SMO.Server($serverConnection)
	$currentLogin= $server.Logins |  Where-Object {$_.Name -eq $currentLoginName}
	$isSysAdmin=$currentLogin.IsMember("SysAdmin")
	return $isSysAdmin
}
# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUzo7baahwu6U21dboM0XIkV2s
# eJugggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFNuItfKvseUKKx2XsSGseiK7r8txMA0GCSqGSIb3DQEBAQUABIGAORux
# kfMcISWcoz0dJxVOhu526iQoh1EVUsA0K7k3xKhouRJxwqfz3/t+YsFepzrfReXn
# X8yzt7sQBBaUsKxTN8dQrMwiQlRP6vclD1kHHvzXc4vpYU7VSxCZKUie5OdSETdy
# lT/9GtMXgVy0JgNiqCEYqHrIqKJTdCoe42F03Es=
# SIG # End signature block
