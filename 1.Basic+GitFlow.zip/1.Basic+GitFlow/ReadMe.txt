#1
Создать пустой репозитарий.
Добавить в него 1 файл с именем MyFirstFile.txt

#2
В репозитарии создать 3 ветки. 
Develop от master,
Feature1 от Develop,
Feature2 от Develop

#3
Сделать комит в ветку Feature1. В комите в файл MyFirstFile.txt добавить строчку "Hello"
Сделать комит в ветку Feature2. В комите в файл MyFirstFile.txt добавить 5 строчек
H
e
l
l
o

#4
Создать из ветки master ветку hotfix.
В ветке hotfix сделать 2 комита.
В первом создать файл HotFixFil.txt с 1 строкой в нем "HotFix"
Во втором комите дописать в файл вторую строку "HotFix2"

#5
Rebase master поверх hotfix

#6
Rebase develop поверх master
Rebase feature1 поверх develop 
Rebase feature2 поверх develop 

#7
В ветку feature1 добавить файл Feature1File.txt
В ветку feature2 добавить файл Feature2File.txt

#8
Слить изменения из ветки feature1 (разработка в которой окончена) в ветку develop.
Сделать это используя rebase develop на feature1.

#9
Сделать rebase feature1 на develop.
Попутно решить merge conflict.

#10
Удалить ветку hotfix1.

#11
Создать ветку release01 от ветки develop.
В ней будет готовится release.
В эту ветку сделать commit файла "ReleaseFix.txt"

#12
считая что из ветки release01 был произведен релиз, сделать rebase ветки master на release01.
Затем провести rebase develop на master.
Сделать rebase feature2 на develop.
удалить ветку feature1.

#13
Считаем что коммит в ветке feature2 не нужен. Откатим его сделав revert commit.
Создать ветку feature3 из develop. добавить туда 3 файла Feature3.txt, Feature3.1.txt, Feature3.2.txt

#14
Создать ветку feature4 от develop.
Добавить в нее папку f4 и в ней 4 файла.
Feature1File.txt,HotFixFile.txt,MyFirstFile.txt,ReleaseFix.txt

#15
Сделать rebase ветки develop поверх feature3.
удалить feature3

#16
Создать  ветку HotFix2 от master
В ветку добавить папку hotfix.
В папку добавить файл HotFix2.xlsx
Закомитить эти изменения.
Ветку develop rebase на feature2

#17
rebase master на hotfix2
rebase develop на master
rebase feature2 на master
rebase feature4 на develop

#18
rebase develop на feature4
delete feature 4
delete feature 2
создание из develop ветки release-candidate2

#19
rebase master на release-candidate2
rebase develop на master
переименовать release-candidate2 в release2