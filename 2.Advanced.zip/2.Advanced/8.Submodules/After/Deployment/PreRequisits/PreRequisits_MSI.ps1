﻿. .\Shared\Shared_Logs.ps1

function InstallMSI($msiFullPathLocal,$logPath)
{
	#http://msdn.microsoft.com/en-us/library/aa367536(VS.85).aspx
	#addlocal=all нужно для установки всех фичей возможных. Если не надо, то метод надо использовать другой
	
	#qn- установка без ui.
	#l*v логи

	$installMSICommand="msiexec /I " + $msiFullPathLocal+" ADDLOCAL=ALL /qn /l*v " + $logPath +" | out-null"
	Log ("installMSICommand: " +$installMSICommand )
	iex $installMSICommand 
}

function InstallWebDeployInstaller($msiFullPathLocal,$logPathLocal)
{
	LogImportant ("Call InstallWebDeployInstaller")
	
	$selectWebDeployQuery="SELECT * FROM Win32_Product WHERE Name LIKE '%Microsoft Web Deploy 3.5%'"
	$webDeploy = gwmi -query $selectWebDeployQuery -ErrorAction Stop
	if($webDeploy -ne $null)
	{
		Log ("Web Deploy already installed.")
		Log ("Full Name: " +$webDeploy.Name)
		return
	}
	else
	{
		$logPathNew=$logPathLocal.Replace(".txt",("_"+$globalComputerName+"_webDeploy.txt"))
		InstallMSI $msiFullPathLocal $logPathNew	
	}
}

function InstallWebPlatfowmInstaller($msiFullPathLocal,$logPathLocal)
{
	#http://support.microsoft.com/kb/314881/ru
	#$msiFullPathLocal="F:\Soft\WebPlatformInstaller_amd64_en-US.msi"
	#$logPathLocal="F:\Soft\log.txt"
	LogImportant ("Call InstallWebPlatfowmInstaller")
	
	$selectWebPlatfromInstallerQuery="SELECT * FROM Win32_Product WHERE Name LIKE '%Microsoft Web Platform Installer 4.6%'"
	$webPlatfrom = gwmi -query $selectWebPlatfromInstallerQuery -ErrorAction Stop
	if($webPlatfrom -ne $null)
	{
		Log ("Web Platfrom Installer  already installed.")
		Log ("Full Name: " +$webPlatfrom.Name)
		return
	}
	else
	{
		$logPathNew=$logPathLocal.Replace(".txt",("_"+$globalComputerName+"_webPI.txt"))
		InstallMSI $msiFullPathLocal $logPathNew
	}
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU1ozlN0H3FepTSMR7Rohuml9A
# Fz2gggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFGH/uLqV90wTdzDRnl8LG1y4YqhnMA0GCSqGSIb3DQEBAQUABIGAU1fo
# GnKrY7jP9QwFoLGopTGRKppOJXxO608kzY/hcyik6WWjhkJUuvkmh7cJHEDDrLWU
# fVIuNtmB+o0vRTvN9XzaA9+JzfM7w0qObOkbEkmPzR7308JxQ7Q+nUTy6vIxdmPU
# 1qsvjPXpUcIJyu61rAJxlUF7l1uJIpaR3GJ7tUs=
# SIG # End signature block
