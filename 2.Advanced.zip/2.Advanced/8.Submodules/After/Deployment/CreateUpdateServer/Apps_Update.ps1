﻿function GoToMSDeploy
{
	LogImportant ("Call GoToMSDeploy")
	$msDeployKey = 'HKLM:\SOFTWARE\Microsoft\IIS Extensions\MSDeploy'
	$msDeployKeyValue =	(Get-ItemProperty -Path $msDeployKey -ErrorAction Stop)
	
	if($msDeployKeyValue -ne $null)
	{
		$msdeployVersion = $msDeployKeyValue.LatestVersion;
		if($msdeployVersion -eq $null)
		{
			$msDeployChildren=(Get-ChildItem -Path $msDeployKey -ErrorAction Stop).PSChildName
			if($msDeployChildren -eq $null)
			{
				LogError "msdeployVersion: is null. Problems with register or with msdeploy intallation."
				ExitCorrect
			}
			else
			{
				LogWarning "MSDeploy Installation was with problems. Register key LatestVersion is absend"
				$msdeployVersion=$msDeployChildren
			}		
		}
		
		$msdeployKeyFullPath=$msDeployKey+"\"+$msdeployVersion
		if($msdeployKeyFullPath -eq $null)
		{
			LogError ("msdeployKeyFullPath: null")
			ExitCorrect
		}
		Log $msdeployKeyFullPath
		$msdeployFullPath =	(Get-ItemProperty -Path $msdeployKeyFullPath -ErrorAction Stop ).InstallPath
		
		if($msdeployFullPath -eq $null)
		{
			LogError ("msdeployFullPath: null")
			ExitCorrect
		}
		
		cd $msdeployFullPath
		$msdeployFullPath=$msdeployFullPath+"msdeploy.exe"
		Log ("MSDeploy path: "+ $msdeployFullPath)
	}
	else
	{
		LogError "MSDEPLOY not installed"
		ExitCorrect
	}
}

function UpdateApp($ComputerName, $UpdateAppPackagePath, $UpdateAppPackageParamPath, $NewAppServiceFolderNameLocal, $NewAppServiceVersionLocal, $RootWebSiteName, $session)
{
	
	#<#
	#.Synopsis
	#	Update application
	#.Description
	#	Update application
	#.Parameter $ComputerName
	# 	ComputerName
	#.Parameter $UpdateAppPackagePath
	#    full path and package name using for update.F:\Deploy\Vtb24.Services.Dms.Web_Package\Vtb24.Services.Dms.Web.zip
	#.Parameter $UpdateAppPackageParamPath
	#    full path and param file name using for update. F:\Deploy\Vtb24.Services.Dms.Web_Package\Vtb24.Services.Dms.Web.SetParameters.xml
	#.Parameter $NewAppServiceFolderNameLocal
	#
	#.Parameter $NewAppServiceVersionLocal
	#
	#.Parameter $RootWebSiteName
	#
	##>
	
	LogImportant ("Call UpdateApp")
		
	GoToMSDeploy
	$msdeployParams="-source:package=$UpdateAppPackagePath -dest:auto,computerName=$ComputerName,includeAcls=False -verb:sync -disableLink:AppPoolExtension -disableLink:ContentExtension -disableLink:CertificateExtension -setParamFile:$UpdateAppPackageParamPath"
	$msdeployCommandPath="msdeploy.exe "+$msdeployParams
	Log "MSDeploy Command $msdeployCommandPath"
	cmd.exe /C $msdeployCommandPath 
	
	
	#при деплои по умолчанию берется из базы. Чтобы перетереть нужно вызвать эту команду
	$applicationVirtualPath = $NewAppServiceFolderNameLocal+"/"+$NewAppServiceVersionLocal
	
	if($session -ne $null)
	{
		Log ("Run using Invoke-Command")
		
		Invoke-Command -Session $session -ScriptBlock {Import-Module ApplicationServer -ErrorAction Stop}
		Invoke-Command -Session $session -ScriptBlock {
			param($RootWebSiteName,$applicationVirtualPath) 
			if($RootWebSiteName -eq $null)
			{
				Write-Host ("RootWebSiteName : is null")
			}
			if($applicationVirtualPath -eq $null)
			{
				Write-Host ("applicationVirtualPath : is null")
			}
			Set-ASAppSqlServicePersistence –SiteName $RootWebSiteName –VirtualPath $applicationVirtualPath -UseInherited -ErrorAction Stop
		} -ArgumentList $RootWebSiteName, $applicationVirtualPath
	}
	else
	{
		Log ("Run  NOT using Invoke-Command")
		Import-Module ApplicationServer -ErrorAction Stop	
		Log "Set-ASAppSqlServicePersistence –SiteName $RootWebSiteName –VirtualPath $applicationVirtualPath -UseInherited" 
		Set-ASAppSqlServicePersistence –SiteName $RootWebSiteName –VirtualPath $applicationVirtualPath -UseInherited
	}
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUUxAASYLHD92c8DpNR9klyEfD
# JDGgggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFD3voxe+btwtpk/vN48X4ajyh8qVMA0GCSqGSIb3DQEBAQUABIGAJg3D
# Ovy7ohS/14PSUsNV+6BGNQVRouX21zDsMy9gaFGmPZlSopNr67Fi2ncQ/2juIX+u
# OuzfVHQWEt9OpM8aEreZ+40oIp7v7w52I+z6iuNjCu9oOTR+GfER1QSiYC7ycnPZ
# 24zJ7xdREQr/yLSgqc1FjNkSJfE0v8YSJ46EQK8=
# SIG # End signature block
