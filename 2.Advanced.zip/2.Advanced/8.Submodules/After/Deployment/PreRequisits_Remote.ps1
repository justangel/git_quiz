﻿param (
$server,
$WindowsImagePath,
$LogPathLocal,
$WindowsFeatureListPath,
$WebPlatfowmInstallerPath,
$WebDeployInstallerPath,
$SQLImagePath,
$IsInstallDB,
$IsInitDB,
$PersistanceConnectionLocal,
$PersistanceConnectionNameLocal,
$PersistenceStoreNameLocal,
$PersistanceDatabaseServerNameLocal,
$PersistenceAdminsGroupName,
$PersistenceReadersGroupName,
$PersistenceUsersGroupName,
$MonitoringConnectionLocal,
$MonitoringConnectionNameLocal,
$MonitoringDatabaseNameLocal,
$MonitoringDatabaseServerNameLocal,
$MonitoringAdminsGroupName,
$MonitoringReadersGroupName,
$MonitoringWritersGroupName,
$AppFabricInstallerLocalPath,
$AppFabricInstallationLogFileLocation
)

$globalComputerName = $server
. .\Shared\Shared_Logs.ps1
. .\Shared\Shared_Validate.ps1
. .\AppFabric\AppFabric_InitializeDB.ps1
. .\AppFabric\AppFabric_Configure.ps1
. .\AppFabric\AppFabric_Main.ps1
. .\SQLServer\SQLServer_ValidateRights.ps1
. .\SQLServer\SQLServer_Install.ps1
. .\PreRequisits\PreRequisits_InstallWindowsFeatures.ps1
. .\PreRequisits\PreRequisits_MSI.ps1

CheckOsServerOrClient $server
#Log("Call New-CimSession")
#$cimSession = New-CimSession -ComputerName $Env:COMPUTERNAME
#Log("EndCall New-CimSession")
#Log($cimSession)
$mountWindowsLetter = MountDiskImage $WindowsImagePath #$cimSession

$WindowsDistribLocal=($mountWindowsLetter+":\sources")
InstallWindowsFeatures $WindowsDistribLocal $LogPathLocal $WindowsFeatureListPath

CheckIISInstaled $server

InstallWebPlatfowmInstaller $WebPlatfowmInstallerPath $LogPathLocal
	
InstallWebDeployInstaller $WebDeployInstallerPath $LogPathLocal

if($IsInstallDB -eq $true)
{
	Log ("Params: $windowsDistribLocal | $SQLDistribLocal | $SQLServerConfigFileFullPath | $SQLServerFeaturespath" )
	$mountSQLLetter = MountDiskImage $SQLImagePath
	$SQLDistribLocal = $mountSQLLetter+":\"
	InstallSQLServer $WindowsDistribLocal $SQLDistribLocal $SQLServerConfigFileFullPath $SQLServerFeaturespath $SQLInstanceName $IsTestEnvironment
	DismountDiskImage $SQLImagePath
}
else
{
	Log ("IsInstallDBString: $IsInstallDBString" )
	Log ("IsInstallDB: $IsInstallDB" )
}

AppFabric

DismountDiskImage $WindowsImagePath

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUeCNje5LX+9pfWdDeLhKvsucb
# 9gWgggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFL6tVbu91GV1RQt9Dt2sT+qcj6C8MA0GCSqGSIb3DQEBAQUABIGAOUCJ
# 8cgrIcVAuEuoE1JtCPaD6kLDIrlSNMyDNriHrd0puiomDIYhoO/Q54K0OxXBdC8J
# /DLWa5pTIX/ZGfZ+mDUfSo2J3mL1DMRVpkLrtbmzEKxbVBvMP+iF6jTz6KDnj/tl
# VdsN5bVbKo06nHeE5gMS79rDk5BAUqN45mpyNmM=
# SIG # End signature block
