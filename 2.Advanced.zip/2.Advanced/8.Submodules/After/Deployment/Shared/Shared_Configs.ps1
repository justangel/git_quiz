﻿function CreateTempDir ($TempDirPathLocal)
{
	$istempDirExist= Test-Path -Path $TempDirPathLocal -ErrorAction Stop
	if($istempDirExist -eq $false)
	{
		New-Item -ItemType directory -Path $TempDirPathLocal -ErrorAction Stop
	}
}

function GetFeaturesFromFile($FeaturesPath)
{	
	$importantFeatures=@()	
	$fileContent = Get-Content $FeaturesPath -ErrorAction Stop
	foreach ($element in $fileContent)
	{
		if(!$element.StartsWith("#"))
		{
			$importantFeatures+=$element
		}
	}
	return $importantFeatures
}

function ReadConfig( $filePath)
{
	LogImportant "Call ReadConfig" 

	Log ("Get-Content Started "+$filePath)
	$fileContent = Get-Content $filePath -ErrorAction Stop
	
	$index=0
	foreach ($element in $fileContent)
	{
		#ignore comments
		if($element.StartsWith("#"))
		{	
			continue
		}
	
		$splittedArray = $element.Split("=")
		if($splittedArray.Length -eq 0)
		{
			continue
		}
		
		$isKeyContained= $parametersHashSetLocal.ContainsKey($splittedArray[0])
		if($isKeyContained -eq $true)
		{
			LogError ("Key was added below" +$splittedArray[0]+" index:"+$index)
			Exit 
		}
		
		if($splittedArray.Length -ne 2)
		{
			$parametersHashSetLocal.Add($splittedArray[0],$element.Replace(($splittedArray[0]+"="),""))	
		}
		else
		{
			$parametersHashSetLocal.Add($splittedArray[0],$splittedArray[1])	
		}
		$index=$index+1
		
	}
	Log "All Configs formated correct"
}

function GetParameterByName($paramName)
{	
	if($parametersHashSetLocal.ContainsKey($paramName) -eq $false)
	{
		$errorEvent = "Key $paramName not exist"
		LogError $errorEvent
		Exit 
	}
	$parametrToRet=$parametersHashSetLocal.Item($paramName)
	return $parametrToRet
}

function GetBoolValueByName($paramName)
{
	$IsInitDBString = GetParameterByName $paramName
	$IsInitDB = $false
	if($IsInitDBString -eq "TRUE")
	{
		$IsInitDB=$true
	}
	return $IsInitDB
}

function GetServerList($ServerListPath)
{
	LogImportant ("Call GetServerList")
	Log ("Server Path: " + $ServerListPath)
	$serverList=@()
	$fileContent = Get-Content $ServerListPath -ErrorAction Stop
	foreach ($element in $fileContent)
	{
		if(!$element.StartsWith("#"))
		{
			$serverList+=@($element)
		}			
	}
	
	if($serverList.Count -eq 0)
	{
		LogError "Server list is emthy"
		Exit
	}
	else
	{
		Log ("Servers list:")
		foreach ($server in $serverList)
		{
			Log ("	"+$server)
		}
	}
	return $serverList
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU203LkWl6N8IIGL2ut0vwY4UR
# DbCgggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFO17lr5Qgr5JY/slXSPXb1fifUhmMA0GCSqGSIb3DQEBAQUABIGAJrZR
# gAbR2SId6sc6LdUe6FskCNRxbMCPImawqGLFoEi/HuDe2GRJ8MPCTXG2SKb6c+5P
# U6lpWUpbIYAXwjbtTbf6ICGmHmKoArfsAfh89fkLDRyP4D/n6hf6oc7xiMg9RX8y
# Ygg1mozbWBG6lvYcnleWU5ugNLdNFDLgowR4rt0=
# SIG # End signature block
