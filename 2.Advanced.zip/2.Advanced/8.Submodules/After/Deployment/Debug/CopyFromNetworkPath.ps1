﻿# скрипт только для отладки на виртуалке. Копирует файлы и все

$LogPathLocal="C:\windows\temp\sbpm_deploy\installog.txt"
$TempDirPathLocal="C:\windows\temp\sbpm_deploy"
$parametersHashSetLocal=@{}
$istempDirExist= Test-Path -Path $TempDirPathLocal
if($istempDirExist -eq $false)
{
	New-Item -ItemType directory -Path $TempDirPathLocal
	$fullDirPath=($TempDirPathLocal+"\Deployment")
	New-Item -ItemType directory -Path $fullDirPath
}
$networkPath="\\10.69.9.37\Deployment"
$localPath="C:\windows\temp\sbpm_deploy"

function CopyScriptsAndConfigLocally
{
	Write-Host ("ChangePath to cd" + $networkPath)
	cd $networkPath

	$isDirectoryExists = Test-Path -Path $localPath 
	if($isDirectoryExists -eq $true)
	{
		Write-Host ("Path: "+$localPath +"exist. CleanUp it")
		Remove-Item -Recurse -Force $localPath
	}
	#Write-Host "Create Folded"
	#New-Item -ItemType directory -Path $localPath
	Write-Host "Copy Local"
	Copy-Item $networkPath $localPath -recurse

	#Get-ChildItem –path $networkPath -Recurse | Foreach-Object  { copy-item -Path $_.fullname -Destination $localPath }
}
CopyScriptsAndConfigLocally
cd $localPath
